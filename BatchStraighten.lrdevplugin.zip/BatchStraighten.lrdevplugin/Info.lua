return {
  LrSdkVersion = 6.0,
  LrSdkMinimumVersion = 6.0,
  LrToolkitIdentifier = 'com.aravi.batchstraighten',
  LrPluginName = 'Batch Straighten',
  LrLibraryMenuItems = {
    { title = 'Auto Straighten (Crop Panel Auto)', file = 'StraightenCrop.lua' },
    { title = 'Calibrate Auto Button Position', file = 'Calibrate.lua' },
    { title = 'Auto Straighten (Transform Tools)', file = 'StraightenTransform.lua' },
  },
  LrExportMenuItems = {
    { title = 'Auto Straighten (Crop Panel Auto)', file = 'StraightenCrop.lua' },
    { title = 'Calibrate Auto Button Position', file = 'Calibrate.lua' },
    { title = 'Auto Straighten (Transform Tools)', file = 'StraightenTransform.lua' },
  },
  VERSION = { major = 1, minor = 2, revision = 0, build = 5 },
}
