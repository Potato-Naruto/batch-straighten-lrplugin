local LrDialogs = import 'LrDialogs'
local LrPathUtils = import 'LrPathUtils'
local LrPrefs = import 'LrPrefs'
local LrTasks = import 'LrTasks'
local LrApplicationView = import 'LrApplicationView'
local LrDevelopController = import 'LrDevelopController'

LrTasks.startAsyncTask(function()
  LrApplicationView.switchToModule('develop')
  LrTasks.sleep(1)
  pcall(function() LrDevelopController.selectTool('crop') end)

  LrDialogs.message('Calibrate Auto button',
    'Lightroom is now in Develop with the Crop & Straighten panel open.\n\n' ..
    '1. Click OK.\n' ..
    '2. Within 6 seconds, hold the mouse pointer still on the "Auto" button next to the Angle slider.\n\n' ..
    'Do not click. The plugin will remember where the pointer is.', 'info')
  LrTasks.sleep(6)

  local out = LrPathUtils.child(_PLUGIN.path, 'pos.txt')
  local script = LrPathUtils.child(_PLUGIN.path, 'getpos.ps1')
  local stale = io.open(out, 'w') -- Lightroom has no os.remove; truncate instead
  if stale then stale:close() end
  LrTasks.execute('"powershell -NoProfile -ExecutionPolicy Bypass -File "' .. script .. '" > "' .. out .. '""')

  local fh = io.open(out, 'r')
  local text = fh and fh:read('*a') or ''
  if fh then fh:close() end
  local x, y = text:match('(%-?%d+),(%-?%d+)')
  if not x then
    LrDialogs.message('Calibrate Auto button', 'Could not read the pointer position.', 'critical')
    return
  end
  local prefs = LrPrefs.prefsForPlugin()
  prefs.autoX, prefs.autoY = tonumber(x), tonumber(y)
  LrDialogs.message('Calibrate Auto button', 'Saved Auto button position: ' .. x .. ', ' .. y ..
    '\n\nRe-run this if you move or resize the Lightroom window or change panel layout.', 'info')
end)
