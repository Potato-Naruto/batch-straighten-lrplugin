local LrApplication = import 'LrApplication'
local LrApplicationView = import 'LrApplicationView'
local LrDevelopController = import 'LrDevelopController'
local LrDialogs = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrPathUtils = import 'LrPathUtils'
local LrPrefs = import 'LrPrefs'
local LrProgressScope = import 'LrProgressScope'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local UPRIGHT_LEVEL = 2
local CROP_KEYS = { 'CropLeft', 'CropRight', 'CropTop', 'CropBottom' }

local function get(key)
  local ok, v = LrTasks.pcall(function() return LrDevelopController.getValue(key) end)
  if ok then return v end
  return nil
end

local function waitForSettle(key, minWait, timeout)
  local last, stable, waited = nil, 0, 0
  while waited < timeout do
    LrTasks.sleep(0.25)
    waited = waited + 0.25
    local v = get(key) or 0
    if last ~= nil and math.abs(v - last) < 1e-6 and waited >= minWait then
      stable = stable + 1
      if stable >= 3 then return true end
    else
      stable = 0
    end
    last = v
  end
  return false
end

local function saveCrop()
  local c = {}
  for _, k in ipairs(CROP_KEYS) do c[k] = get(k) end
  return c
end

local function restoreCrop(c)
  for _, k in ipairs(CROP_KEYS) do
    if c[k] ~= nil then LrDevelopController.setValue(k, c[k]) end
  end
end

local function showResults(header, rows)
  LrFunctionContext.callWithContext('results', function()
    local f = LrView.osFactory()
    LrDialogs.presentModalDialog {
      title = 'Batch Straighten - Done',
      contents = f:column {
        spacing = f:control_spacing(),
        f:static_text { title = header, font = '<system/bold>' },
        f:scrolled_view {
          width = 520, height = 360, horizontal_scroller = false,
          f:static_text { title = table.concat(rows, '\n'), width = 490, height_in_lines = #rows },
        },
      },
      actionVerb = 'OK',
      cancelVerb = '< exclude >',
    }
  end)
end

-- Clicks the real "Auto" button in the Crop & Straighten panel.
local function clickAuto(x, y)
  local script = LrPathUtils.child(_PLUGIN.path, 'click.ps1')
  return LrTasks.execute(string.format(
    '"powershell -NoProfile -ExecutionPolicy Bypass -File "%s" %d %d"', script, x, y))
end

local function cropAuto(prefs)
  local crop = saveCrop()
  local before = get('straightenAngle') or 0
  LrDevelopController.selectTool('crop')
  LrTasks.sleep(0.7)
  clickAuto(prefs.autoX, prefs.autoY)
  LrTasks.sleep(0.8)
  local settled = waitForSettle('straightenAngle', 1.5, 10)
  local after = get('straightenAngle') or 0
  restoreCrop(crop)
  LrTasks.sleep(0.4)
  local note = ''
  if math.abs(after - before) < 1e-6 then note = '  (no change - already level, or Auto button not hit)' end
  return string.format('%+.2f deg%s', after, note), settled
end

local function transformLevel()
  local crop = saveCrop()
  local beforeRot = get('PerspectiveRotate') or 0
  LrDevelopController.setValue('PerspectiveUpright', UPRIGHT_LEVEL)
  local settled = waitForSettle('PerspectiveRotate', 1.5, 15)
  local rot = get('PerspectiveRotate') or 0
  restoreCrop(crop)
  LrTasks.sleep(0.4)
  return string.format('%+.2f deg (Transform Rotate, was %+.2f)', rot, beforeRot), settled
end

local M = {}

function M.run(mode)
  LrTasks.startAsyncTask(function()
    local prefs = LrPrefs.prefsForPlugin()
    if mode == 'crop' and not (prefs.autoX and prefs.autoY) then
      LrDialogs.message('Batch Straighten',
        'First run "Calibrate Auto Button Position" from the Plug-in Extras menu so the plugin knows where the Crop panel\'s Auto button is.',
        'info')
      return
    end

    local catalog = LrApplication.activeCatalog()
    local photos = catalog:getTargetPhotos()
    if #photos == 0 then
      LrDialogs.message('Batch Straighten', 'Select one or more photos first.', 'info')
      return
    end

    LrApplicationView.switchToModule('develop')
    LrTasks.sleep(1)

    local progress = LrProgressScope { title = 'Batch Straighten' }
    local rows = {}

    for i, photo in ipairs(photos) do
      if progress:isCanceled() then break end
      progress:setPortionComplete(i - 1, #photos)
      local name = photo:getFormattedMetadata('fileName')
      progress:setCaption(name)

      local ok, a, b = LrTasks.pcall(function()
        catalog:setSelectedPhotos(photo, { photo })
        LrTasks.sleep(1.2)
        if mode == 'crop' then return cropAuto(prefs) end
        return transformLevel()
      end)
      if ok then
        rows[#rows + 1] = string.format('%s:  %s%s', name, a, b and '' or '  [may not have finished]')
      else
        rows[#rows + 1] = string.format('%s:  FAILED (%s)', name, tostring(a))
      end
    end

    catalog:setSelectedPhotos(photos[1], photos)
    progress:done()
    showResults(mode == 'crop' and 'Crop & Straighten "Auto" angles (degrees):'
      or 'Transform > Level rotation (degrees):', rows)
  end)
end

return M
